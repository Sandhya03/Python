import time

import requests
import os
import re
import pandas as pd
import util
import sys
import config as cfg
from datetime import datetime
import re

verifycols_list = cfg.collist

local_file_path = cfg.other_information['localfilepath']
lastruntime = util.read_lastrundate()
strlastruntime = lastruntime[:19].replace("T"," ")

class SPOnline(object):

    def __init__(self, site_url):
        self.site_url = site_url

    def __exit__(self, ext_type, exc_value, traceback):
        if isinstance(exc_value, Exception):
            self.site_url=""

    def send_get_req(self, api_url: str, headers) -> bytes:
        print(api_url)
        response = requests.get(api_url, headers=headers, verify=False)

        if response.status_code != 200:
            util.logger.info(response.status_code)

        return response
        
    def getallsites(self,site_url, headers):

        util.logger.info("Step 1 - get all sites.")
        # step 1
        api_path = "_api/web/webs"
        api_url = f"{self.site_url}/{api_path}"
        util.logger.info(f"sending request to {api_url} ")

        subsite_response = self.send_get_req(api_url, headers)

        sites_list = []
        web_list_result = subsite_response.json()['d']['results']
        for count, name in enumerate(web_list_result, start=1):
            sites_list.append(name['__metadata']['id'])

        util.logger.info("main regions sites")
        util.logger.info(sites_list)
        #print(sub_sites_list)
        return sites_list

    def getallsubsites(self,site_list, headers):

        util.logger.info("Step 2 - get all subsites.")
        # step 1
        api_path = "webs"

        sub_sites_list = []
        
        for site in site_list:
            api_url = f"{site}/{api_path}"
            util.logger.info(f"sending request to {api_url} ")
            site_response = self.send_get_req(api_url, headers)

            web_list_result = site_response.json()['d']['results']
            for count, name in enumerate(web_list_result, start=1):
                sub_sites_list.append(name['__metadata']['id'])

        util.logger.info("sub sites list")
        util.logger.info(sub_sites_list)
        #sub_sites_list = ['https://bakerhughes.sharepoint.com/sites/CPS/dev/APAC/Australia/_api/Web']

        return sub_sites_list

# STEP 2 - get lists for subsites
    def getlistcollection(self,subsites,headers):
        util.logger.info("Step 3 - get lists for subsite")
        subsite_list = []
        for subsite in subsites:
            api_url = f"{subsite}/webs"

            util.logger.info(f"\nsending request to {api_url}")
            web_r = self.send_get_req(api_url, headers)

            web_result = web_r.json()['d']['results']
            for count, element in enumerate(web_result, start=1):

                list_name = element['Lists']['__deferred']['uri']
                subsite_list.append(list_name)
        
        util.logger.info("Total list collection", len(subsite_list))
        #util.logger.info(subsite_list)
        #subsite_list = ['https://bakerhughes.sharepoint.com/sites/CPS/dev/APAC/Australia/oilsearch_australia/_api/Web/Lists',
        #'https://bakerhughes.sharepoint.com/sites/CPS/dev/APAC/Australia/woodsideenergy/_api/Web/Lists']
        return subsite_list

    def get_guid_list(self, subsite_list, headers):
        util.logger.info("Step 4 - get folder api with guid")
        root_folder_list = []

        # STEP 4 - traverse through subsites_lists and send requests lto ist_api
        for list_api in subsite_list:

            util.logger.info(f"Sending request to {list_api}")
            list_response = self.send_get_req(list_api, headers=headers)

            list_r = list_response.json()['d']['results']
            for count, metadata in enumerate(list_r, start=1):
                    root_folder_path = metadata['RootFolder']['__deferred']['uri']
                    root_folder_list.append(root_folder_path)
     
        return root_folder_list

    def get_list_folders(self, guid_list,headers, ignore_list):
        util.logger.info("Step 5 - get folder list from rootfolder")
        folder_list= []
        # STEP 5 - sending request to root folder api and parse response to get file api
        for count, rootpath_api in enumerate(guid_list, start=1):

            util.logger.info(f"{count} Sending request to {rootpath_api}")
            response = self.send_get_req(rootpath_api, headers=headers)
            
            folder_list_name = response.json()['d']['Name']

            if folder_list_name not in ignore_list:
                folder_path = response.json()['d']['__metadata']['id']
                folder_list.append(folder_path)

        return folder_list

    def get_list_files(self, folder_list, headers):
        util.logger.info("Step 6 - get file api from folder")
        # traversing through files through folders and get list of file apis
        files_list_api = []
        for count, folder_api in enumerate(folder_list, start=1):

            util.logger.info(f"{count} Sending request to {folder_api}")
            response = self.send_get_req(folder_api, headers=headers)

            #TimeLastModified = response.json()['d']['TimeLastModified']

            file_api_path = response.json()['d']['Files']['__deferred']['uri']
            """
            if TimeLastModified > strlastruntime:
                files_list_api.append(file_api_path)
            else:
                util.logger.info(f"file has not been modified since {TimeLastModified}")
            """

            files_list_api.append(file_api_path)
        return files_list_api

    def download_files(self, files_list_api, headers):
        util.logger.info("Step 7 - file download process started --")
        # STEP 7 - collect file apis in list
        file_match_cnt = 0
        file_downloaded_list = []

        for count, files_api in enumerate(files_list_api, start=1):
            util.logger.info(f"{count} Sending request to file api {files_api}")

            file_response = self.send_get_req(files_api, headers)
            metadata = file_response.json()['d']['results']

            # extract individual file api and send request
            for data in (metadata):

                file_count = 1
                file_path_api = data['__metadata']['id']
                match_found = re.search(r"decodedurl='([^'']+)'", file_path_api, flags=0)

                if match_found:

                    timeLastModified = data['TimeLastModified']
                    checkOutByUser = data['CheckedOutByUser']
                    listItemAllFields = data['ListItemAllFields']
                    exists = data['Exists']
                    title = data['Title']
                    
                    file_api = match_found.group(1)

                else:
                    util.logger.info("file path not found.")

                # extract file name only
                file_name = os.path.basename(file_api)

                # match file name pattern
                match_obj = re.compile(r"^(Data Pull).*")
                match = match_obj.match(file_name)

                if match and timeLastModified > strlastruntime:
                    fname = match.group(1)

                    # send request to file api
                    url = f"{self.site_url}/_api/web/GetFileByServerRelativeUrl('{file_api}')/$value"

                    file_response = self.send_get_req(url, headers=headers)
                    file_match_cnt +=1

                    timestr_obj = datetime.strptime(timeLastModified,"%Y-%m-%dT%H:%M:%SZ")
                    timeLastModified = timestr_obj.strftime("%m%d%Y")
                    f_name = time.strftime("%m%d%Y")+"_"+fname+"_"+timeLastModified+".xlsx"

                    local_download_path = local_file_path + "/" + f_name
 
                    # write content of response file to a local file
                    with open(local_download_path, 'wb') as file:
                        file.write(file_response.content)
                    util.logger.info(f'{file_match_cnt} File downloaded successfully to: {local_download_path}')

                    tpl = (file_path_api, f_name)
                    file_downloaded_list.append(tpl)

                else:
                    util.logger.info(f'Different file name found {file_name}.')
        return file_downloaded_list

    def convert_to_csv(self,slno,sitefilepath,filename,file_path,colslist_verify=verifycols_list):
        _nret = 0
        message_list = []

        global xl
        csvfile = file_path+"/"+filename.split(".")[0]+".csv"
        
        try:
            df = pd.DataFrame()
            xlfname = file_path+"/"+filename
            
            #xl = pd.ExcelFile(xlfname)
            with pd.ExcelFile(xlfname) as xl:
                i=1
                for sheet in xl.sheet_names:
                    if i==1:
                        df_tmp = xl.parse(sheet)
                        df = pd.concat([df, df_tmp])

                        i=i+1
                _lcolslist= list(df.columns)

                df['file link']=sitefilepath
                lnret,retmessage= util.list_compare(_lcolslist,colslist_verify)
                if lnret==1:
                    df.to_csv(csvfile, index=False)
                    _nret= 1
                    message_list=["csv convert success"]

                else:
                    _nret= 0
                    message_list=["csv convert failed"]+retmessage
        except Exception as ex:
            util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                        sys.exc_info()[1],
                        sys.exc_info()[2].tb_lineno))
            _nret= 0
            message_list=["csv convert failed",ex]
        finally: 
            if 'xl' in globals():
                del xl
            if os.path.isfile(xlfname):
                os.remove(xlfname)

        return _nret,message_list,(slno,csvfile,filename.split(".")[0]+".csv")