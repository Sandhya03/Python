## Config.py##
ignorelib_list_org = ['Announcements',
	'Calendar',
	'Links',
	'Master Page Gallery',
	'SiteAssets',
	'SitePages',
	'Tasks',
	'Team Discussion'
]

# just adding new names to ignore to test 
ignorelib_list = ['Announcements',
	'Calendar',
	'Links',
	'Master Page Gallery',
	'SiteAssets',
	'SitePages',
	'Tasks',
	'Team Discussion',
    'WS',
    'PublishedFeed',
    'MultiPL',
    'masterpage',
    'OFS_WS',
    'OFS_WS_Woodside',
    'PP',
    'DS',
]

email_info = {
    "smtphost":"smtp.aws.geogcloud.com",
    "recipients":" ",
    "sender":""
}
collist=['DM#','Project ID','Opportunity ID','Customer','Opportunity','Region','Country','Product Line','Sub-Product Line','Status',
	'Case','Active','Fiscal Year','Quarter','Sales Revenue Excluding LIH','Service Revenue','Rental Revenue Excluding LIH','Lost in Hole/Upsell Revenue',
    	'Freight Revenue','3rd Party Pass Thru Revenue','Total Revenue','Standard Cost Net of GPI (Gross Profit in Inventory)','Total Lost in Hole Cost / Upsell Cost',
	'Freight - Purchases and Delivery','Freight - Mobilization and Demobilization','Customs and Duties','Warranty Cost of Sales','Third Party Pass Thru Costs',
	'Third Party Costs','Rental Tool Depreciation (Incremental CAPEX)','Rental Tool Depreciation (Existing Tools)','Rental Tool Repair and Maintenance',
    	'Other Miscellaneous Expenses',	'Salaries & Wages - Service Supervision','Rent Expense','Repairs & Maintenance','Travel & Entertainment','Supplies',
    	'Agent / JV Fees','QA/QC, Inspection & Testing Expenses','Contingencies','Professional Services (Including Temp Personnel)','Total Cost of Revenue',
	'Contribution Margin','CM%','Non-Rental Tool Depreciation & Depletion - New','Burden Rate','Field Margin','FM% ex Allocations','HQ Allocations','Operating Income',
	'% Operating Income','Inventory Purchases','New Rental Tool CAPEX','New Non-Rental Tool CAPEX','New Headcount','Existing Headcount','CPS Quarter',
    	'Prepared by ','FP&A','HR','Upsell Revenue','Upsell Cost','Upsell Margin','RONCE','NPV Cash Flow'
]

sp_user_credentials={
	'username': 'svc-cps',
    'password': 'bMii^Y!no84G;9SuYsP~*49_1',
	'domain': 'BHI-MASTER',
}
sftp_credentials_bk={
	'hostname': 'bhlhcaspia-sftpcommon01001np-prod.prd-0000156.pause1.bakerhughes.com',
	'username': 'svc-bhlh_cps_pr',
	'password': 'ecKxwrzChcK8wpR+wrTChsKawrfCpMKrwpbCjsK/wppmwpzChcODwqzCvMKddXs=',
	'port': '22',
	'remotefilepath': '/579173156905-us-east-1-bhlhcaspia-sftpcommon01001/CPS_Analytics',
	'remotelogfilepath': '/579173156905-us-east-1-bhlhcaspia-sftpcommon01001/CPS_Analytics',
    'local_file_path': 'C:/Users/pawasan01/cps/files_from_sp'
}
other_information={
	'SProotURL': 'https://bakerhughes.sharepoint.com/sites/OFSSharePointContentTeam/ofsgco',
	'localfilepath': 'C:/Users/pawasan01/cps/logdata',
	'logpath': 'C:/Users/pawasan01/cps/log',
}

sp_user_credentials={
	'username': 'svc-cps',
    'password': 'bMii^Y!no84G;9SuYsP~*49_1',
	'domain': 'BHI-MASTER',
}
# prod 
sftp_credentials={
	'hostname': '10.124.1.70',
	'username': 'pawasan01',
	'password': '',
	'port': '22',
	'remotefilepath': '/xdata/CPS_Analytics',
	'remotelogfilepath': '/xdata/CPS_Analytics/python_log',
}

sftp_credentials_bk={
	'hostname': 'bhlhcaspia-sftpcommon01001np-prod.prd-0000156.pause1.bakerhughes.com',
	'username': 'svc-bhlh_cps_pr',
	'password': 'wqzCvcKiw4PCvMOaw4LCisK2w5LCu8Kww4nDlMKhc8OKwqbCnHfCscOswpbDicODw4PCnsKvw6fCu8OEw4fCrsOmwrTCj8Ocw4B+wqLDnMOSw4nCtMORw4fDhcKIw5DCq8KWwpLDpsOhw7LClcOawpzCk8K3wpjCoMKnwoY=',
	'port': '22',
	'remotefilepath': '/579173156905-us-east-1-bhlhcaspia-sftpcommon01001/CPS_Analytics',
	'remotelogfilepath': '/579173156905-us-east-1-bhlhcaspia-sftpcommon01001/CPS_Analytics',
}
other_information={
    #'SProotURL': 'https://bakerhughes.sharepoint.com/sites/OFSSharePointContentTeam/ofsgco',
	'SProotURL': 'https://bakerhughes.sharepoint.com/sites/CPS/dev',
	'localfilepath': 'C:/Users/pawasan01/cps/files_from_sp',
    'logpath': 'C:/Users/pawasan01/cps/log',
}

sp_client_credentials={
    'ClientId': 'c5d05331-9ec6-4a01-9184-105849e6b474@d584a4b7-b1f2-4714-a578-fd4d43c146a6',
    'ClientSecret': 'ryg8Q~f21wFdcRmTwNeliEdV~i8BS73YWqp-DaF1',
    'resource': '00000003-0000-0ff1-ce00-000000000000/bakerhughes.sharepoint.com@d584a4b7-b1f2-4714-a578-fd4d43c146a6',
    'token_url': 'https://accounts.accesscontrol.windows.net/d584a4b7-b1f2-4714-a578-fd4d43c146a6/tokens/OAuth/2'
}
