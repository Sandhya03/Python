import encryptde as encrypt
import util
import config as cfg
import requests
import sys
import sp_file_download
import time
import paramiko
import db_opreation as db_sqllite
import uuid
import warnings
warnings.filterwarnings('ignore')

tablename="cps_job_log_al"
logpath = cfg.other_information['logpath']
sftp_host= cfg.sftp_credentials['hostname']
sftp_user= cfg.sftp_credentials['username']
sgtp_psss= cfg.sftp_credentials['password']
sftp_port= int(cfg.sftp_credentials['port'])
sftp_remotefilepath= cfg.sftp_credentials['remotefilepath']
sftp_remotelogfilepath= cfg.sftp_credentials['remotelogfilepath']
local_file_path = cfg.other_information['localfilepath']
ignorelib_list = cfg.ignorelib_list

# main site url
root_url = cfg.other_information['SProotURL']
util.logger.info(root_url)
logpath =  cfg.other_information['logpath']
gsqllitepath = logpath+"/"+"log.db"
#gsqllitepath = "log.db"
gjobid = uuid.uuid1().hex
_nret = 0

firstlastruntime ='2020-01-01T00:00:00.000Z'   
lastruntime = util.read_lastrundate()
strlastruntime = lastruntime[:19].replace("T"," ")
todayruntime = time.strftime("%Y-%m-%dT%H:%M:%S.000Z")
#todayruntime = time.strftime("%Y-%m-%d")
strtodayruntime = todayruntime[:19].replace("T"," ")


def get_token():
    # credentials
    client_id = cfg.sp_client_credentials['ClientId']
    client_secret = cfg.sp_client_credentials['ClientSecret']
    resource = cfg.sp_client_credentials['resource']
    token_url = cfg.sp_client_credentials['token_url']

    # create token payload
    token_data = {
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
        'resource': resource
    }

    # sending request to generate token
    token_r = requests.post(token_url, data=token_data)

    # get access token
    access_token = token_r.json().get('access_token')

    if access_token:
        print("Access token acquired successfully.")
        util.logger.info("Access token acquired successfully.")
    else:
        print(token_r.status_code)
        util.logger.info(token_r.status_code)

    headers = {
        "Accept": "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose",
        "Authorization": f"Bearer {access_token}"
    }
    return headers

def filesftp(slnowithsftpfilenamepath_tuplelist=None,sftp_host=sftp_host,sftp_user=sftp_user,sgtp_psss=sgtp_psss,sftp_port=sftp_port,sftp_remotefilepath=sftp_remotefilepath):
    ftp_load_cnt = 0

    try:
        util.logger.info("Creating SFTP Object.")
        transport = paramiko.Transport((sftp_host, 22))
        transport.connect(username=sftp_user, password=sgtp_psss)

        sftp = paramiko.SFTPClient.from_transport(transport)
        util.logger.info("Connected.")

        for slnowithfilenamepath_tuple in (slnowithsftpfilenamepath_tuplelist):

            slno, _localfilepath, filename = slnowithfilenamepath_tuple
            util.logger.info(f"File sftp process started. local file: {_localfilepath},remote file: {sftp_remotefilepath}")
            remotefilepath = sftp_remotefilepath+"/"+filename

            _nret = 0

            try:
                sftp.put(_localfilepath,remotefilepath)
                sftp.chmod(remotefilepath,mode=777)

                _nret = 1
            except Exception as e:
                print(e)
                _nret = 0

            if _nret == 0:
                message = "sftp failed"
                ## log to DB
                #log_update(["sftp_status", "note"], [_nret, message], ["slno", "jobid"], [slno, gjobid])

                ## log to file
                util.logger.info("File sftp job is not succeed for :%s " % _localfilepath)

            if _nret == 1:

                message = "sftp success"
                ## log to DB
               # log_update(["sftp_status", "note"], [_nret, message], ["slno", "jobid"], [slno, gjobid])
                #log_update(["sftp_file_name", "note"], [filename, message], ["slno", "jobid"], [slno, gjobid])

                ## log to file
                util.logger.info("File sftp job is succeed for :%s " % _localfilepath)
                ftp_load_cnt = ftp_load_cnt + 1

    except Exception as ex:
         util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
               sys.exc_info()[1],
               sys.exc_info()[2].tb_lineno))
         print(ex)
    finally:
        if 'sftp' in locals():
           sftp.close()
           print("SFTP connection closed.")
           util.logger.info("File sftp job is completed")

    return ftp_load_cnt

def create_table(sql):
    try:
        if len(sql)>0:
            with db_sqllite.sqllite(gsqllitepath) as db:
                db.create_table(sql)
    except Exception as ex:
        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                    sys.exc_info()[1],
                    sys.exc_info()[2].tb_lineno))    
                   
def log_insert(alllistpath_site_url_list_name,jobrundate,jobid=gjobid,tablename="cps_job_log_al"):
    print(f"inserting details in log table {alllistpath_site_url_list_name}")
    util.logger.info("inserting details in log table {alllistpath_site_url_list_name}")
    try:
        if len(alllistpath_site_url_list_name)>0:
            rows=[]
            for i,r_file_ID_filepath_site_url_Listname in enumerate(alllistpath_site_url_list_name):

                r_fileID,r_filepath,site_url,list_name = r_file_ID_filepath_site_url_Listname
                row={"slno":i,"jobid":jobid,"JOB_RUN_DATE":jobrundate,"sp_file_id":r_fileID,"sp_file_url":r_filepath,"sp_site_url":root_url,"sp_list_name":list_name}

                rows.append(row)
            with db_sqllite.sqllite(gsqllitepath) as db:
                db.sqllite_insert(tablename,rows)
    except Exception as ex:
        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                    sys.exc_info()[1],
                    sys.exc_info()[2].tb_lineno)) 
                    
def log_update(flds_list,values_list,key_flds_list,value_flds_list,tablename="cps_job_log_al"):
    try:
        with db_sqllite.sqllite(gsqllitepath) as db:
            db.sqllite_update(tablename,flds_list,values_list,key_flds_list,value_flds_list)
    except Exception as ex:
        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                    sys.exc_info()[1],
                    sys.exc_info()[2].tb_lineno))
                    
def sqltolist(sql,selectcol):
    
    try:
        rettuple_list=[]
       
        with db_sqllite.sqllite(gsqllitepath) as db:
            rettuple_list= db.sqltolist(sql,selectcol)

    except Exception as ex:
        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                    sys.exc_info()[1],
                    sys.exc_info()[2].tb_lineno))
    finally:
        return rettuple_list
        
def main():

    try:
       sp = sp_file_download.SPOnline(site_url=root_url)
    except Exception as ex:
        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                            sys.exc_info()[1],
                            sys.exc_info()[2].tb_lineno))

    # headers
    headers = get_token()
    
    # DB - create table 
        ## Create DB Table if not exist    
    ssql = '''CREATE TABLE IF NOT EXISTS cps_job_log_al(
    ID INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE,
    SLNO INTEGER NOT NULL,
    JOBID VARCHAR(100) NOT NULL,
    JOB_RUN_DATE DATETIME DEFAULT CURRENT_TIMESTAMP,
    sp_file_id VARCHAR(200) NOT NULL,
    SP_FILE_URL VARCHAR(200) NOT NULL,
    sp_site_url VARCHAR(200) NOT NULL,
    sp_list_name VARCHAR(200) NOT NULL,
    DOWNLOAD_STATUS INTEGER DEFAULT 0,
    CSV_STATUS   INTEGER DEFAULT 0,
    SFTP_STATUS  INTEGER DEFAULT 0,
    SFTP_FILE_NAME  VARCHAR(200) DEFAULT ' ',
    CHECK_OUT_USER VARCHAR(50) DEFAULT ' ',
    NOTE  VARCHAR(200) DEFAULT ' ' ,
    IS_DELETED INTEGER DEFAULT 0 )'''
    create_table(ssql)

    alllistpath_site_url_list_name = []
    alllistpath_for_deletion = []
    
    # STEP 2 - get all region sites
    all_sites=sp.getallsites(root_url, headers)
    util.logger.info(f"STEP 0 - all subsites:  {all_sites}")    
  
    # STEP 2 - get all subsites
    all_subsites=sp.getallsubsites(all_sites, headers)
    util.logger.info(f"STEP 1 - all subsites:  {all_subsites}")
    alllistpath_site_url_list_name.append(all_subsites)

    # STEP 3- get lists for subsite
    subsite_list = sp.getlistcollection(all_subsites, headers)
    util.logger.info(f"STEP 2 - lists for subsites: {subsite_list}")
    alllistpath_for_deletion.append(subsite_list)
    
    # STEP 4 - traverse through subsite_list and send requests to rootfolder api with guid
    guid_list = sp.get_guid_list(subsite_list, headers)
    util.logger.info(f"STEP 4 - get all rootfolder lists with guid: {guid_list}")

    # STEP 5 - sending request to guid root folder api and parse response to get folder list
    folder_list = sp.get_list_folders(guid_list, headers, ignorelib_list)
    total_folders = len(folder_list)
    util.logger.info(f"STEP 5 - get all folders list: {total_folders}")
    
    # STEP 6 - traversing through Folders and get files api list
    file_api_list = sp.get_list_files(folder_list, headers)
    total_files = len(file_api_list)
    util.logger.info(f"STEP 6 - get all files list: {total_files}")
    # check files which modified by last run time - need to added
    # lastruntime - dat - need to pupulated
    # naming convenyion as per getlastruntime
    
    # STEP 7 - collect file apis in list and send request to download
    file_downloaded_list = sp.download_files(file_api_list, headers)
    print(len(file_downloaded_list))
    
    filestuple_list = []
    
    if len(file_downloaded_list) > 0:   
        util.logger.info("file download process ---")

        rows = []
        for cnt, tup in enumerate(file_downloaded_list, start=1):
            sitefilepath, file_name = tup

            filepath, fileurl = sitefilepath.split("(decodedurl='")
            
            row={"slno":cnt,"jobid":gjobid,"JOB_RUN_DATE":strtodayruntime,"sp_file_id":filepath,"sp_file_url":fileurl[:-1],"sp_site_url":root_url,"sp_list_name":fileurl[:-1]}
            util.logger.info(f"Inserting rows {row}")
            rows.append(row)
            rows = []
            
            with db_sqllite.sqllite(gsqllitepath) as db:
                db.sqllite_insert(tablename,rows)
                
            util.logger.info("file convert to csv process started --")
            _nret, message, slnowithsftpfilename_tuple = sp.convert_to_csv(cnt, sitefilepath, file_name, local_file_path)

            if _nret==1:
                filestuple_list.append(slnowithsftpfilename_tuple)   

    lnpad = 65
    util.logger.info("Total data pull files ready to send sftp server: %d "%len(filestuple_list))
    
    if len(filestuple_list)>0:
            printlbl= "files sftp job start-"+time.strftime("%Y-%m-%d %H:%M:%S")
            print(printlbl.center(lnpad,"#"))

            sftpfilescount = filesftp(slnowithsftpfilenamepath_tuplelist=filestuple_list)
            util.logger.info("Total data pull files have been sent sftp server: %d "%sftpfilescount)
            printlbl= "files sftp job end-"+time.strftime("%Y-%m-%d %H:%M:%S")
            print(printlbl.center(lnpad,"#"))
    
if __name__ == '__main__':

    time1 = time.strftime("%Y-%m-%d %H:%M:%S")
    util.logger.info(f"time started: {time1}")
    print(f"time : {time1}")
    
    main()

    ## Save current run date                  
    util.save_lastrundate(todayruntime)
    time2 = time.strftime("%Y-%m-%d %H:%M:%S")
    util.logger.info(f"time completed: {time2}")
    print(f"time : {time2}")