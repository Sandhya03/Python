'''## created on Apr 2020##'''
import requests
import xml.etree.ElementTree as ET
import json
import urllib3
import win32com.client
import time
import datetime
import os
import shutil
import csv
import pandas as pd
import win32process
import win32gui
import win32api
import win32con
import base64
import sys
import uuid 
urllib3.disable_warnings()

import util

class SP2010(object):
    def __init__(self,
                site_url=None,  # type: str
                auth=None, # type: httpntlmauth
                ):
        if site_url is  None:
            raise NotImplementedError("root site is not supported!")
        if auth is  None:
            raise NotImplementedError("Authentication is not supported!")
        self.site_url = site_url
        self.auth = auth    
    def __enter__(self):
        return self
    def __exit__(self, ext_type, exc_value, traceback):
        if isinstance(exc_value, Exception):
            self.site_url=""
            self.auth=None
    def getallsubsites(self):
        url =self.site_url+"/_vti_bin/webs.asmx"
        print(url)
        list_allsubsites=[]
        payload = '''
        <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
        <soap:Body>
            <GetAllSubWebCollection xmlns="http://schemas.microsoft.com/sharepoint/soap/" />
        </soap:Body>
        </soap:Envelope>
        '''
        r = requests.post(url,auth=self.auth,
            headers = {
                'SOAPAction'  : 'http://schemas.microsoft.com/sharepoint/soap/GetAllSubWebCollection',           
                'Content-Type' : 'text/xml; charset=utf-8'
                #'Content-Type': 'application/json; odata=verbose'
            },
            data = payload,verify =False
        )
        print(r.status_code)
        if r.status_code == 200:
            site_content = ET.fromstring(r.content)
            for child in site_content.iter('{http://schemas.microsoft.com/sharepoint/soap/}Web'):
                if not child.attrib['Title'].startswith("[NOT TO USE]") or not child.attrib['Title'].startswith("[MOVED]"):
                    url= child.attrib['Url']
                    list_allsubsites.append(url)
        return list_allsubsites      
    def getlistcollection(self,sub_site_url=None,ignorelib_list=None):
        if sub_site_url is  None:
            raise NotImplementedError("Sub Site is not supported or empty!")
            return
        _list=[]
        sub_site_url =sub_site_url+"/_vti_bin/lists.asmx"
        payload = ''' 
        <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
            <soap:Body>
                <GetListCollection xmlns="http://schemas.microsoft.com/sharepoint/soap/" />
            </soap:Body>
        </soap:Envelope>    
        '''
        r = requests.post(sub_site_url,auth=self.auth,
            headers = {
                'SOAPAction'  : 'http://schemas.microsoft.com/sharepoint/soap/GetListCollection',
                'Content-Type' : 'text/xml; charset=utf-8'
            },
            data = payload,verify =False
        )
        if r.status_code == 200:
            root = ET.fromstring(r.content)
            for child in root.iter('{http://schemas.microsoft.com/sharepoint/soap/}List'):
                if (child.attrib['BaseType'] =="1") and not (child.attrib['Title'] in ignorelib_list):
                    if not child.attrib['Title'].startswith("[NOT TO USE]") or not child.attrib['Title'].startswith("[MOVED]"):
                        _list.append(child.attrib['Name'])
        return sub_site_url,_list           
        
    def getlistitem(self,sub_site_url,list_name,cutofftime,file_Name=None):
        payload = ''' 
        <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
        <soap:Body>
                        <GetListItems xmlns='http://schemas.microsoft.com/sharepoint/soap/'> 
                            <listName>{}</listName>
                            <query>    
                                <Query>
                                    <Where>
                                    <Or>
                                    <Gt><FieldRef Name='Modified'/><Value Type='DateTime' IncludeTimeValue='TRUE' >{}</Value></Gt>
                                    <Eq><FieldRef Name='FileLeafRef'/><Value Type='File'  >{}</Value></Eq>
                                    </Or>
                                    </Where>
                                </Query>
                            </query>  
                            <queryOptions>
                            <QueryOptions />
                            </queryOptions>                        
                            <viewFields><ViewFields/></viewFields>
                        </GetListItems> 
        </soap:Body>
        </soap:Envelope>
        '''
        payload = payload.format(list_name,cutofftime,file_Name)
        r = requests.post(sub_site_url,auth=self.auth,
            headers = {
                'SOAPAction'  : "http://schemas.microsoft.com/sharepoint/soap/GetListItems",
                'Content-Type' : 'text/xml; charset=utf-8'
            },
            data = payload,verify =False
        )
        tuple_path = ()
        if r.status_code == 200:
            root = ET.fromstring(r.content)
            _ows_CheckedOutTitle = ""
            file_path_temp = ""
            file_path = ""
            file_path_ID = ""
            pass_flag = False
            for child in root.iter('{urn:schemas-microsoft-com:rowset}data'):
                #if int(child.attrib['ItemCount']) >1:
                for child in root.iter('{#RowsetSchema}row'):
                    if len(_ows_CheckedOutTitle)==0:
                        _ows_CheckedOutTitle = child.attrib["ows_CheckedOutTitle"].split("#")[1]                    
                    time1=cutofftime
                    time2=child.attrib["ows_Modified"]
                    a=datetime.datetime.strptime(time1,"%Y-%m-%dT%H:%M:%S.000Z")
                    b=datetime.datetime.strptime(time2,"%Y-%m-%d %H:%M:%S")
                    util.write_file("******"+child.attrib["ows_Modified"]+"-"+child.attrib["ows_EncodedAbsUrl"]+"_"+child.attrib["ows_CheckedOutTitle"].split("#")[1],filename="log_details.txt")
                    if b>a:
                        pass_flag = True
                    if child.attrib["ows_BaseName"].title()==file_Name.split(".")[0].title():
                        file_path_temp=child.attrib["ows_EncodedAbsUrl"]
                        file_path_ID=child.attrib["ows_UniqueId"].split("#")[1]
                if pass_flag==True:
                    file_path = file_path_temp
        return file_path,(file_path_ID,file_path,sub_site_url,list_name)    
    def getcheckoutuser(self,sub_site_url,list_name):
        payload = ''' 
        <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
        <soap:Body>
                        <GetListItems xmlns='http://schemas.microsoft.com/sharepoint/soap/'> 
                            <listName>{}</listName>
                            <query>    
                                <Query>
                                </Query>
                            </query>  
                            <queryOptions>
                            <QueryOptions />
                            </queryOptions>                        
                            <viewFields><ViewFields/></viewFields>
                        </GetListItems> 
        </soap:Body>
        </soap:Envelope>
        '''
        payload = payload.format(list_name)
        r = requests.post(sub_site_url,auth=self.auth,
            headers = {
                'SOAPAction'  : "http://schemas.microsoft.com/sharepoint/soap/GetListItems",
                'Content-Type' : 'text/xml; charset=utf-8'
            },
            data = payload,verify =False
        )
        _ows_CheckedOutTitle = ""
        if r.status_code == 200:
            root = ET.fromstring(r.content)
            for child in root.iter('{urn:schemas-microsoft-com:rowset}data'):
                for child in root.iter('{#RowsetSchema}row'):
                    _ows_CheckedOutTitle = child.attrib["ows_CheckedOutTitle"].split("#")[1]
                    if len(_ows_CheckedOutTitle)>0:
                        break 
                if len(_ows_CheckedOutTitle)>0:
                    break                         
        return _ows_CheckedOutTitle    
    
    def fileexist(self,remotefilepath):
        lreturn = False
        try:
            with requests.get(remotefilepath, auth=self.auth,stream=True,verify =False) as r:
                if r.status_code == 200:
                       lreturn = True
                else:       
                       lreturn = False
        except Exception as ex:
            util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                        sys.exc_info()[1],
                        sys.exc_info()[2].tb_lineno))
            lreturn = False            
        finally:
            return lreturn    
    def filedownloadex(self,slnositefilewithcheckedoutuser_tuple,localfilename,localfilepath):
        _nret = 0
        message=""
        checkedout_flag = False
        _slnowithfilepathdownloaded_tuple = ()
        slno,sitefilewithcheckedoutusertitle_tuple = slnositefilewithcheckedoutuser_tuple
        sitefilepath,checkedoutusertitle = sitefilewithcheckedoutusertitle_tuple
        _slnowithfilepathdownloaded_tuple=(slno,sitefilepath)
        sitefilepath=sitefilepath.replace("%20", " ")        
        xlapp = win32com.client.DispatchEx("Excel.Application")
        try:
            if self.fileexist(sitefilepath)==True:
                outfile = localfilepath+"/"+localfilename
                if (xlapp.Workbooks.CanCheckOut(sitefilepath) == True):
                    #xlapp.Workbooks.CheckOut(sitefilepath)
                    xlapp.Application.DisplayAlerts = False
                    xlapp.Application.AskToUpdateLinks = False
                    xlbk = xlapp.Application.Workbooks.Open(sitefilepath,3)
                    time.sleep(50)
                    xlapp.Application.Workbooks("Data Pull.xlsx").RefreshAll
                    #xlapp.Application.Workbooks("Data Pull.xlsx").Save
                    xlapp.Application.Workbooks("Data Pull.xlsx").SaveCopyAs(outfile)
                    xlapp.Application.AskToUpdateLinks = True
                    xlapp.Application.DisplayAlerts = True
                    #xlapp.Application.Workbooks("Data Pull.xlsx").CheckIn(False)
                    xlapp.Application.Workbooks("Data Pull.xlsx").Close(False)                    
                    _nret = 1
                    message ="Download success"
                else:
                    _nret = 0
                    message = "File is already checkout by {} ".format(checkedoutusertitle)
                    checkedout_flag=True
            else:
                _nret = 0 
                message = "File is either removed or renamed or deleted in site"
        except Exception as ex:
            util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                        sys.exc_info()[1],
                        sys.exc_info()[2].tb_lineno))
            _nret = 0
            message = "File download failed"                    
        finally:
            xlapp.Quit()
            util.close_excel_by_force(xlapp)
            return _nret,checkedout_flag,checkedoutusertitle,message,_slnowithfilepathdownloaded_tuple
    def convert_to_csv(self,slnowithfilepathdownloaded_tuple,filename,file_path,colslist_verify=None):
        _nret = 0
        message_list=[]
        slno,sitefilepath = slnowithfilepathdownloaded_tuple
        global xl
        csvfile = file_path+"/"+filename.split(".")[0]+".csv"         
        try:
            df = pd.DataFrame()
            xlfname = file_path+"/"+filename
            xl = pd.ExcelFile(xlfname)
            i=1
            for sheet in xl.sheet_names:
                if i==1:
                    df_tmp = xl.parse(sheet)
                    df = df.append(df_tmp, ignore_index=True,sort=False)
                    i=i+1
            _lcolslist= list(df.columns)
            df['file link']=sitefilepath
            lnret,retmessage= util.list_compare(_lcolslist,colslist_verify)
            if lnret==1:
                df.to_csv(csvfile, index=False)
                _nret= 1
                message_list=["csv convert success"]
            else:
                _nret= 0
                message_list=["csv convert failed"]+retmessage
        except Exception as ex:
            util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                        sys.exc_info()[1],
                        sys.exc_info()[2].tb_lineno))
            _nret= 0
            message_list=["csv convert failed",ex]
        finally: 
            if 'xl' in globals():
                del xl
            if os.path.isfile(xlfname):
                os.remove(xlfname)
            return _nret,message_list,(slno,csvfile,filename.split(".")[0]+".csv")
def main():
    with SP2010() as SP:
        pass
if __name__ == '__main__':
    main()            
