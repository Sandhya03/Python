'''## Created on Apr 2020##'''
import csv
import time
import sqlite3
from sqlite3 import Error
import sys
import pandas as pd


import util

import uuid 
JobID=id = uuid.uuid1().hex
class sqllite(object):
    def __init__(self, db_location=None):
        """Initialize db class variables"""
        if db_location is not None:
            self.connection = sqlite3.connect(db_location)
        else:
            self.connection = sqlite3.connect(self.DB_LOCATION)
        self.cur = self.connection.cursor()
    def __enter__(self):
        return self
    def __exit__(self, ext_type, exc_value, traceback):
        self.cur.close()
        if isinstance(exc_value, Exception):
            self.connection.rollback()
        else:
            self.connection.commit()
            self.connection.close()        
    def sql_exc(self,strsql):
        cur = self.cur
        cur.execute(strsql)
        self.commit()         
        return cur
        
    def sqltolist(self,sql,selectcol=2):

        cur = self.cur
        cur.execute(sql)
        rows=cur.fetchall()

        util.logger.info(f"sql = {sql}")
        util.logger.info(f"rows = {rows}")
        
        temptuple_list =[]        
        for row in rows:
            if selectcol==1:
                temptuple_list.append(row[0])
            if selectcol==2:
                temptuple_list.append((row[0],row[1]))
            if selectcol==3:
                temptuple_list.append((row[0],row[1],row[2]))
            if selectcol==4:
                temptuple_list.append((row[0],row[1],row[2],row[3]))
            if selectcol==5:
                temptuple_list.append((row[0],row[1],row[2],row[3],row[4]))                            
        return temptuple_list   
        
    def create_table(self,ssql=""):
        cur = self.cur
        cur.execute(ssql)
    def sqllite_insert(self,tablename,data_list_dict):
        for rec in data_list_dict:
            keys = ','.join(rec.keys())
            question_marks = ','.join(list('?'*len(rec)))
            values = tuple(rec.values())
            self.connection.execute('INSERT INTO '+tablename+' ('+keys+') VALUES ('+question_marks+')', values)
            self.commit() 
    def sqllite_update(self,tablename,flds_list,values_list,key_flds_list,value_flds_list):
        cur = self.cur
        sql = ''' UPDATE {}
              SET {} = ? ,
                  {} = ? 
              WHERE {} = ? and {}= ?'''
        sql=sql.format(tablename,flds_list[0],flds_list[1],key_flds_list[0],key_flds_list[1])
        values_tuple = tuple(values_list+ value_flds_list)
        
        self.connection.execute(sql, values_tuple)
        self.commit()  
    def commit(self):
        """commit changes to database"""
        self.connection.commit()
    def sqllite_to_csv(self,sql,csvfilepath):
        db_df = pd.read_sql_query(sql, self.connection)
        db_df.to_csv(csvfilepath, index=False)
def main():    
    #gsQLPath = "D:\TECHM\PN94884\POC\myproject\SP\log\Log.DB"
    gsQLPath = "C:/Users/pawasan01/Python Scrip/log/log.DB"
    try:
        with sqllite(gsQLPath) as db:
            sql ="select SP_FILE_URL from cps_job_log_al where date(JOB_RUN_DATE)=date('2020-06-16 04:54:47') and SFTP_STATUS=0"
            yemp=db.sqltolist(sql,selectcol=1)
            print(yemp)
    except Exception as ex:
        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                    sys.exc_info()[1],
                    sys.exc_info()[2].tb_lineno))
if __name__ == '__main__':
    main()