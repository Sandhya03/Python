'''## created on Apr 2020##'''

import requests
from requests_ntlm import HttpNtlmAuth
import time
import os
import pysftp
import base64

import sys
import uuid 

import encryptde as encrypt
import util
import config as cfg
import db_opreation as db_sqllite
import SP

##**************read config file************
logpath =  cfg.other_information['logpath']

gsqllitepath = logpath+"/"+"log.db"

rooturl = cfg.other_information['SProotURL']

localfilepath =  cfg.other_information['localfilepath']

sp_domain = cfg.sp_user_credentials['domain']
sp_username = cfg.sp_user_credentials['username']
sp_passwd = cfg.sp_user_credentials['password']
sp_passwd = base64.b64encode(sp_passwd.encode('utf-8'))
#sp_passwd = bytes(sp_passwd, 'ascii')
#sp_passwd=encrypt.decode(sp_passwd)
sftp_host= cfg.sftp_credentials['hostname']
sftp_user= cfg.sftp_credentials['username']
sgtp_psss= cfg.sftp_credentials['password']
sgtp_psss = bytes(sgtp_psss, 'ascii')
sgtp_psss=encrypt.decode(sgtp_psss)
sftp_port= int(cfg.sftp_credentials['port'])
sftp_remotefilepath= cfg.sftp_credentials['remotefilepath']
sftp_remotelogfilepath= cfg.sftp_credentials['remotelogfilepath']

#smtphost= cfg.email_info['smtphost']
#recipients= cfg.email_info['recipients']
#sender= cfg.email_info['sender']

ignorelib_list = cfg.ignorelib_list
verifycols_list= cfg.collist
##***************
gjobid = uuid.uuid1().hex
##***************

def filesftp(slnowithsftpfilenamepath_tuplelist=None,sftp_host=sftp_host,sftp_user=sftp_user,sgtp_psss=sgtp_psss,sftp_port=sftp_port,sftp_remotefilepath=sftp_remotefilepath):
    filescount= len(slnowithsftpfilenamepath_tuplelist)
    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None
    #util.printprogressbar(0, filescount, prefix = 'progress:', suffix = 'complete', length = 50)
    nuploadcount=0
    util.logger.info("File sftp job is started")
    try:       
        with pysftp.Connection(host=sftp_host,port=sftp_port, username=sftp_user, password=sgtp_psss,cnopts=cnopts) as sftp:
                for i,slnowithfilenamepath_tuple in  enumerate(slnowithsftpfilenamepath_tuplelist):
                    message= "" 
                    _nret  = 0
                    slno,_localfilepath,filename = slnowithfilenamepath_tuple
                    util.logger.info("File sftp job is started for :%s "%_localfilepath)                    
                    try:
                        #util.printprogressbar(i+1, filescount, prefix = 'progress:', suffix = 'complete', length = 50)
                        remotefilepath = sftp_remotefilepath+"/"+filename
                        sftp.put(_localfilepath, remotefilepath)
                        sftp.chmod(remotefilepath,mode=777)
                        nuploadcount = nuploadcount+1
                        _nret = 1
                    except Exception as ex:
                        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                            sys.exc_info()[1],
                            sys.exc_info()[2].tb_lineno))
                        message=sys.exc_info()[1]
                        _nret = 0
                        continue
                    finally:
                        if _nret==0:
                            message = "sftp failed"
                            ## log to DB
                            log_update(["sftp_status","note"],[_nret,message],["slno","jobid"],[slno,gjobid])
                            ##
                            ## log to file
                            util.logger.info("File sftp job is not succeed for :%s "%_localfilepath) 
                            ##    
                        if _nret==1:
                            message = "sftp success"
                            ## log to DB
                            log_update(["sftp_status","note"],[_nret,message],["slno","jobid"],[slno,gjobid])							
                            log_update(["sftp_file_name","note"],[filename,message],["slno","jobid"],[slno,gjobid])
                            ##
                            ## log to file
                            util.logger.info("File sftp job is succeed for :%s "%_localfilepath)                                                
							##
    except Exception as ex:
        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                    sys.exc_info()[1],
                    sys.exc_info()[2].tb_lineno))
    finally:
        util.logger.info("File sftp job is completed")
        return nuploadcount
def singlefilesftp(FilewithPath_filename_tuple=None,sftp_host=sftp_host,sftp_user=sftp_user,sgtp_psss=sgtp_psss,sftp_port=sftp_port,sftp_remotefilepath=sftp_remotelogfilepath):
    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None
    _nret=0
    try:       
        with pysftp.Connection(host=sftp_host,port=sftp_port, username=sftp_user, password=sgtp_psss,cnopts=cnopts) as sftp:
                   
                    try:
                        _localfilepath,filename=FilewithPath_filename_tuple 
                        remotefilepath = sftp_remotefilepath+"/"+filename
                        sftp.put(_localfilepath, remotefilepath)
                        _nret = 1
                    except Exception as ex:
                        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                            sys.exc_info()[1],
                            sys.exc_info()[2].tb_lineno))
                        _nret = 0
    except Exception as ex:
        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                    sys.exc_info()[1],
                    sys.exc_info()[2].tb_lineno))
        _nret =0            
    finally:
        return _nret 
def create_table(sql):
    try:
        if len(sql)>0:
            with db_sqllite.sqllite(gsqllitepath) as db:
                db.create_table(sql)
    except Exception as ex:
        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                    sys.exc_info()[1],
                    sys.exc_info()[2].tb_lineno))              
def log_insert(alllistpath_site_url_list_name,jobrundate,jobid=gjobid,tablename="cps_job_log_al"):
    try:
        if len(alllistpath_site_url_list_name)>0:
            rows=[]
            for i,r_file_ID_filepath_site_url_Listname in  enumerate(alllistpath_site_url_list_name):
                
                r_fileID,r_filepath ,site_url,list_name= r_file_ID_filepath_site_url_Listname
                row={"slno":i,"jobid":jobid,"JOB_RUN_DATE":jobrundate,"sp_file_id":r_fileID,"sp_file_url":r_filepath,"sp_site_url":site_url,"sp_list_name":list_name}
                rows.append(row)
            with db_sqllite.sqllite(gsqllitepath) as db:
                db.sqllite_insert(tablename,rows)
    except Exception as ex:
        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                    sys.exc_info()[1],
                    sys.exc_info()[2].tb_lineno))    
def log_update(flds_list,values_list,key_flds_list,value_flds_list,tablename="cps_job_log_al"):
    try:
        with db_sqllite.sqllite(gsqllitepath) as db:
            db.sqllite_update(tablename,flds_list,values_list,key_flds_list,value_flds_list)
    except Exception as ex:
        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                    sys.exc_info()[1],
                    sys.exc_info()[2].tb_lineno))
def sqltolist(sql,selectcol):
    try:
        rettuple_list=[]
        with db_sqllite.sqllite(gsqllitepath) as db:
            rettuple_list= db.sqltolist(sql,selectcol)
    except Exception as ex:
        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                    sys.exc_info()[1],
                    sys.exc_info()[2].tb_lineno))
    finally:
        return rettuple_list
def main():
    ## Create DB Table if not exist    
    ssql = '''CREATE TABLE IF NOT EXISTS cps_job_log_al(
    ID INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE,
    SLNO INTEGER NOT NULL,
    JOBID VARCHAR(100) NOT NULL,
    JOB_RUN_DATE DATETIME DEFAULT CURRENT_TIMESTAMP,
    sp_file_id VARCHAR(200) NOT NULL,
    SP_FILE_URL VARCHAR(200) NOT NULL,
    sp_site_url VARCHAR(200) NOT NULL,
    sp_list_name VARCHAR(200) NOT NULL,
    DOWNLOAD_STATUS INTEGER DEFAULT 0,
    CSV_STATUS   INTEGER DEFAULT 0,
    SFTP_STATUS  INTEGER DEFAULT 0,
    SFTP_FILE_NAME  VARCHAR(200) DEFAULT ' ',
    CHECK_OUT_USER VARCHAR(50) DEFAULT ' ',
    NOTE  VARCHAR(200) DEFAULT ' ' ,
    IS_DELETED INTEGER DEFAULT 0 )'''
    create_table(ssql)
    
    
    lnpad = 65
    ##
    ## log to file
    util.logger.info("Job Started")
    ##    
    all_subsites_list= []
    firstlastruntime='2020-01-01T00:00:00.000Z'   
    lastruntime= util.read_lastrundate()
    #lastruntime='2022-04-26T08:00:00.000Z'
    strlastruntime= lastruntime[:19].replace("T"," ")
    todayruntime = time.strftime("%Y-%m-%dT%H:%M:%S.000Z")
    strtodayruntime= todayruntime[:19].replace("T"," ")
    
    #auth = HttpNtlmAuth(sp_domain+"\\"+sp_username, sp_passwd)
    auth = HttpNtlmAuth('BHI-MASTER\\svc-cps', 'bMii^Y!no84G;9SuYsP~*49_1')
    try:
        sp = SP.SP2010(site_url=rooturl,auth=auth)
        all_subsites_list=sp.getallsubsites()        
    except Exception as ex:
        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                            sys.exc_info()[1],
                            sys.exc_info()[2].tb_lineno))
        sys.exit()    
    if len(all_subsites_list)>0:
        sitescount= len(all_subsites_list)
        
        alllistpath_site_url_list_name = []
        alllistpath_for_deletion =[]
        
        # traversing all site and extract the file list to be downloaded
        printlbl="site traversing job start-"+time.strftime("%Y-%m-%d %H:%M:%S")   
        lnpad = 65    
        print(printlbl.center(lnpad,"#"))
        #util.printprogressbar(0, sitescount, prefix = 'progress:', suffix = 'complete', length = 50)
        for i,sub_site in enumerate(all_subsites_list):
            try:
                #util.printprogressbar(i + 1, sitescount, prefix = 'progress:', suffix = 'complete', length = 50)
                sub_site_url,list_collection = sp.getlistcollection(sub_site_url=sub_site,ignorelib_list=ignorelib_list)
                for list_name in list_collection:
                    try:
                        path,path_site_url_list_name_tuple = sp.getlistitem(sub_site_url,list_name,lastruntime,file_Name="data pull.xlsx")
                        #util.logger.info(f'{path},{path_site_url_list_name_tuple},"testcase"')
                        if len(path_site_url_list_name_tuple)>1 and len(path)>1:
                           alllistpath_site_url_list_name.append(path_site_url_list_name_tuple)
                        ## For Delete list
                        path_d,path_site_url_list_name_tuple_d = sp.getlistitem(sub_site_url,list_name,firstlastruntime,file_Name="data pull.xlsx")
                        if len(path_site_url_list_name_tuple_d)>1 and len(path_d)>1:
                           alllistpath_for_deletion.append(path_d)                        
                        ##                           
                    except Exception as ex:
                        util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                                             sys.exc_info()[1],
                                             sys.exc_info()[2].tb_lineno))
                        continue                                                
            except Exception as ex:
                util.logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                                             sys.exc_info()[1],
                                             sys.exc_info()[2].tb_lineno))
                continue                                                        
        printlbl="site traversing job end-"+time.strftime("%Y-%m-%d %H:%M:%S")
        print(printlbl.center(lnpad,"#"))
        
        ## For Delete list
        sql = "select SP_FILE_URL from cps_job_log_al where datetime(JOB_RUN_DATE)=datetime('"+strlastruntime+"')"
        alllistpath_site_url_lastday= sqltolist(sql,selectcol=1)
        deleted_path_list= [x for x in alllistpath_site_url_lastday if x not in alllistpath_for_deletion] 
        #print(alllistpath_site_url_lastday)
        #print(deleted_path_list)
        #print(alllistpath_for_deletion)
        for deleted_path in deleted_path_list:
            message = "Deleted on "+todayruntime
            log_update(["IS_DELETED","note"],[1,message],["SP_FILE_URL","JOB_RUN_DATE"],[deleted_path,strlastruntime])
        ##
        
        ## get failed path of last run
        sql = "select sp_file_id,SP_FILE_URL,sp_site_url,sp_list_name from cps_job_log_al where datetime(JOB_RUN_DATE)=datetime('"+strlastruntime+"') and SFTP_STATUS=0 and is_deleted=0"
        alllistpath_site_url_list_name_temp= sqltolist(sql,selectcol=4)
        alllistpath_site_url_list_name = alllistpath_site_url_list_name+alllistpath_site_url_list_name_temp
        alllistpath_site_url_list_name = list(dict.fromkeys(alllistpath_site_url_list_name))

        print("#####total data pull files count: ",len(alllistpath_site_url_list_name))
        
        ## log to file
        util.logger.info("Total data pull files to be downloaded: %d"%len(alllistpath_site_url_list_name))
        ##         
        # downloading the files and converting into csv
        filestuple_list= []
        if len(alllistpath_site_url_list_name)>0:
            log_insert(alllistpath_site_url_list_name,strtodayruntime,gjobid)
            printlbl= "file download and refresh job start-"+time.strftime("%Y-%m-%d %H:%M:%S")
            print(printlbl.center(lnpad,"#"))
            sitescount= len(alllistpath_site_url_list_name)
            #util.printprogressbar(0, sitescount, prefix = 'progress:', suffix = 'complete', length = 50)
            for i,path_site_url_list_name in  enumerate(alllistpath_site_url_list_name):
                #util.printprogressbar(i + 1, sitescount, prefix = 'progress:', suffix = 'complete', length = 50)
                path_id,path,site_url,list_name = path_site_url_list_name
                ## get checkout_user_name
                checkout_user_name = sp.getcheckoutuser(site_url,list_name)
                ##
                r_filepathwithcheckedoutuser_tuple = (path,checkout_user_name)
                localfilename = "Data_Pull_"+time.strftime("%m%d%Y%H%M%S")+".xlsx"
                ##Log to file
                util.logger.info("File download job started:%s "%path)  
                ##
                _nret,checkedout_flag,_checkedoutusertitle,message,slnowithfilepathdownloaded_tuple = sp.filedownloadex((i,r_filepathwithcheckedoutuser_tuple),localfilename,localfilepath=localfilepath)
                slno=i
                ## log to DB
                log_update(["download_status","note"],[_nret,message],["slno","jobid"],[slno,gjobid])
                ##
                if checkedout_flag==True:
                    ##log to DB
                    log_update(["check_out_user","note"],[_checkedoutusertitle,message],["slno","jobid"],[slno,gjobid])
                    ##
                ##Log to file
                if _nret==1:
                    util.logger.info("File download job is succeed:%s "%path)
                else:                    
                    util.logger.info("File download job is not succeed:%s "%path)
                ##
                
                if _nret==1:
                    ##Log to file
                    util.logger.info("File CSV convert job is started:%s "%path)  
                    ##                
                    _nret,message,slnowithsftpfilename_tuple = sp.convert_to_csv(slnowithfilepathdownloaded_tuple,localfilename,localfilepath,colslist_verify=verifycols_list)
                    message= ":".join(message)
                    ## log to DB
                    log_update(["csv_status","note"],[_nret,message],["slno","jobid"],[slno,gjobid])
                    ##
                    ##Log to file                    
                    if _nret==1:
                        util.logger.info("File CSV convert job is succeed:%s "%path)  
                    else:
                        util.logger.info("File CSV convert job is not succeed:%s "%path)
                    ##                        
                    if _nret==1:
                        filestuple_list.append(slnowithsftpfilename_tuple)                
            printlbl="file download and refresh job end-"+time.strftime("%Y-%m-%d %H:%M:%S")
            print(printlbl.center(lnpad,"#"))
        ## File SFTP 
        ## log to file
        util.logger.info("Total data pull files ready to send sftp server: %d "%len(filestuple_list))
        ##        
        if len(filestuple_list)>0:
            printlbl= "files sftp job start-"+time.strftime("%Y-%m-%d %H:%M:%S")
            print(printlbl.center(lnpad,"#"))
            sftpfilescount = 0
            sftpfilescount= filesftp(slnowithsftpfilenamepath_tuplelist=filestuple_list)
            util.logger.info("Total data pull files have been sent sftp server: %d "%sftpfilescount)
            printlbl= "files sftp job end-"+time.strftime("%Y-%m-%d %H:%M:%S")
            print(printlbl.center(lnpad,"#"))
        ## log data export to csv and send to sftp server
        if len(alllistpath_site_url_list_name)>0:
            logfilename = "cps_python_log_"+time.strftime("%m%d%Y%H%M%S")+".csv"
            logfilenamewithpath = localfilepath+"/"+logfilename
            with db_sqllite.sqllite(gsqllitepath) as db:
                sql = '''
                    select ID,SLNO,JOBID,JOB_RUN_DATE,SP_FILE_URL,
                    DOWNLOAD_STATUS,CSV_STATUS,SFTP_STATUS,SFTP_FILE_NAME,CHECK_OUT_USER,
                    NOTE,IS_DELETED from cps_job_log_al where jobid='{}'
                    UNION 
                    select ID,SLNO,JOBID,JOB_RUN_DATE,SP_FILE_URL,
                    DOWNLOAD_STATUS,CSV_STATUS,SFTP_STATUS,SFTP_FILE_NAME,CHECK_OUT_USER,
                    NOTE,IS_DELETED from cps_job_log_al where IS_DELETED=1 and JOB_RUN_DATE='{}'
                '''
                sql =sql.format(gjobid,strlastruntime)
                db.sqllite_to_csv(sql, logfilenamewithpath)
            if os.path.isfile(logfilenamewithpath):
                _nret= singlefilesftp((logfilenamewithpath,logfilename))
                if _nret==1:
                    print("Log file spft to sftp server")
                    util.logger.info("Log file spft to sftp server")
        ## Save current run date                  
        util.save_lastrundate(todayruntime)
    else:
        util.logger.info("no site available for traversing")
    ## log to file
    util.logger.info("Job Completed")
    ##         
if __name__ == '__main__':
    main()
