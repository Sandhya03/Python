'''## Created on Apr 2020##'''
import logging
import sys
import logging
import time
import os
import win32process
import win32gui
import win32api
import win32con
import smtplib
import string

import config as cfg


##**************Read Config File************
logpath =  cfg.other_information['logpath']

## Error Logger
logfilepath     = logpath+"/log.log" 
logger          = logging.getLogger(__name__)  
logger.setLevel(logging.INFO)
file_handler    = logging.FileHandler(logfilepath)
formatter       = logging.Formatter('%(asctime)s - %(levelname)5s - %(filename)s:%(funcName)s - %(message)s')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)
#

currentpath=os.path.abspath(os.path.dirname(sys.argv[0]))
def send_email(body_text,Priority,host=None, subject=None, Recipients=None, Sender=None):
    """
    Send an email
    """
    try:
        BODY=""
        BODY = "\r\n".join((
            "From: %s" % Sender,
            "To: %s" % Recipients,
            "Subject: %s" % subject ,
            "X-Priority:%d" % Priority,
            "Content-Type:%s" % "text/plain",
            "",
            body_text
            ))
        server = smtplib.SMTP(host)
        ret=server.sendmail(Sender, Recipients.split(','), BODY)
        print(ret)
        server.quit()
    except Exception as ex:
        logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                    sys.exc_info()[1],
                    sys.exc_info()[2].tb_lineno))   
        print(ex)
def list_compareold(list1,list2):
    nret=0
    if len(list1)==len(list2):
        for index, item in enumerate(list1):
            if item != list2[index]:
                nret= 0
                break
            else:
                nret= 1            
    else:
        nret= 0
    return nret
def list_compare(list1,list2):
    nret=1
    mismatch =[]
    if len(list1) != len(set(list1)):
        mismatch =["Duplicate columns",[x for x in list1 if list1.count(x) > 1]]
        nret = 0
    if len(list1)==len(list2):
        i=0
        for item1, item2 in zip(list1, list2):
            if item1 != item2:
                if i==0:
                    mismatch= ["Mismatched columns"]
                i=i+1
                mismatch.append(item1+"-"+item2)
                nret = 0                
    else:
        res= [x for x in list1+list2 if x not in list1 or x not in list2] 
        if len(res)!=0:
            mismatch=mismatch+["Invalid columns"]+res
            nret = 0 
    return nret,mismatch    
def write_file(data,logPath=logpath,filename="log.txt"):
    file_name = logPath+"/" +filename
    with open(file_name, 'a+') as x_file:
        x_file.write('{}\n'.format(data))

def save_lastrundate(dt,filename="LASTRUNTIME.DAT"):
    try:
        filename=os.path.join(currentpath,filename)
        with open(filename, 'w') as lastruntime_file:
            lastruntime_file.write("Last Run DateTime="+dt)
    except Exception:
        logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                    sys.exc_info()[1],
                    sys.exc_info()[2].tb_lineno))        
def read_lastrundate(filename="LASTRUNTIME.DAT"):
    lastrundate = time.strftime("%Y-%m-%dT%H:%M:%S.000Z")        
    try:
        filename=os.path.join(currentpath,filename)
        with open(filename) as read_lastrundate:
            content = read_lastrundate.read()
            if len(content)>0:
                lastrundate = content.split("=")[1]      
    except Exception:
        logger.error('{}. {}, line: {}'.format(sys.exc_info()[0],
                    sys.exc_info()[1],
                    sys.exc_info()[2].tb_lineno))    
    finally:    
        return lastrundate
def update_list(list,oldvalue,newvalue):
    for idx,item in enumerate(list):
        if oldvalue in item:
           citem =list[idx]+"|"+newvalue 
           list[idx]= citem
    return list        
# Print iterations progress
def printprogressbar (iteration, total, prefix = '', suffix = '', decimals = 1, length = 100, fill = '█', printEnd = "\r"):
    """
    Call in a loop to create terminal progress bar
    """
    percent = ("{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = fill * filledLength + '-' * (length - filledLength)
    print('\r%s |%s| %s%% %s' % (prefix, bar, percent, suffix), end = printEnd)
    # Print New Line on Complete
    if iteration == total: 
        print()
def close_excel_by_force(excel):
    hwnd = excel.Hwnd
    t, p = win32process.GetWindowThreadProcessId(hwnd)
    win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
    time.sleep(10)
    try:
        handle = win32api.OpenProcess(win32con.PROCESS_TERMINATE, 0, p)
        if handle:
            win32api.TerminateProcess(handle, 0)
            win32api.CloseHandle(handle)
    except:
        pass 
def _pretty_write_dict(dictionary):
    def _nested(obj, level=1):
        indentation_values = "\t" * level
        indentation_braces = "\t" * (level - 1)
        if isinstance(obj, dict):
            return "{\n%(body)s%(indent_braces)s}" % {
                "body": "".join("%(indent_values)s\'%(key)s\': %(value)s,\n" % {
                    "key": str(key),
                    "value": _nested(value, level + 1),
                    "indent_values": indentation_values
                } for key, value in obj.items()),
                "indent_braces": indentation_braces
            }
        if isinstance(obj, list):
            return "[\n%(body)s\n%(indent_braces)s]" % {
                "body": "".join("%(indent_values)s%(value)s,\n" % {
                    "value": _nested(value, level + 1),
                    "indent_values": indentation_values
                } for value in obj),
                "indent_braces": indentation_braces
            }
        else:
            return "\'%(value)s\'" % {"value": str(obj)}

    dict_text = _nested(dictionary)
    return dict_text        
if __name__ == '__main__':  
    main()        